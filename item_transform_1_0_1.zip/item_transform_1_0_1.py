bl_info = {
    "name": "Item Transform",
    "version": (1, 0, 1),
    "blender": (4, 0, 0),
    "category": "Object",
    "author": "Dimona Patrick",
    "description": "Quick transform operations for selected objects",
}

import bpy
from bpy.utils import register_class, unregister_class
import functools
from mathutils import Vector, Matrix

# --- Properties ---
class ITEM_TRANSFORM_Properties(bpy.types.PropertyGroup):
    # Transform Factors
    move_factor: bpy.props.FloatProperty(
        name="Move Factor",
        description="Movement multiplier factor",
        default=5.0,
        min=0.0
    )
    
    rotate_factor: bpy.props.FloatProperty(
        name="Rotate Factor",
        description="Rotation multiplier factor (degrees)",
        default=5.0,
        min=0.0
    )
    
    scale_factor: bpy.props.FloatProperty(
        name="Scale Factor",
        description="Scale multiplier factor",
        default=5.0,
        min=0.0
    )

    # Dimensions
    dimensions: bpy.props.FloatVectorProperty(
        name="Dimensions",
        description="Object dimensions (X, Y, Z)",
        size=3,
        default=(1.0, 1.0, 1.0),
        min=0.0,
        unit='LENGTH'
    )

    # Pivot point settings
    pivot_point: bpy.props.EnumProperty(
        name="Pivot Point",
        items=[
            ('CENTER', 'Center', 'Use object center'),
            ('ORIGIN', 'Origin', 'Use object origin'),
            ('CURSOR', '3D Cursor', 'Use 3D cursor'),
            ('INDIVIDUAL', 'Individual Origins', 'Use individual origins'),
            ('MEDIAN', 'Median Point', 'Use median point')
        ],
        default='CENTER'
    )

# --- Transform Operators ---
class OBJECT_OT_QuickTransform(bpy.types.Operator):
    bl_idname = "object.quick_transform"
    bl_label = "Quick Transform"
    bl_options = {'REGISTER', 'UNDO'}
    
    transform_type: bpy.props.StringProperty()
    direction: bpy.props.StringProperty()
    
    def execute(self, context):
        props = context.scene.item_transform_props
        
        for obj in context.selected_objects:
            if self.transform_type == 'MOVE':
                factor = props.move_factor
                if self.direction == 'UP':
                    obj.location.z += factor
                elif self.direction == 'DOWN':
                    obj.location.z -= factor
                elif self.direction == 'LEFT':
                    obj.location.x -= factor
                elif self.direction == 'RIGHT':
                    obj.location.x += factor
                elif self.direction == 'FORWARD':
                    obj.location.y += factor
                elif self.direction == 'BACKWARD':
                    obj.location.y -= factor
                    
            elif self.transform_type == 'ROTATE':
                factor = props.rotate_factor
                if self.direction == 'X':
                    obj.rotation_euler.x += factor
                elif self.direction == 'Y':
                    obj.rotation_euler.y += factor
                elif self.direction == 'Z':
                    obj.rotation_euler.z += factor
                    
            elif self.transform_type == 'SCALE':
                factor = props.scale_factor / 100.0  # Convert to percentage
                if self.direction == 'UP':
                    obj.scale *= (1 + factor)
                elif self.direction == 'DOWN':
                    obj.scale *= (1 - factor)
                    
        return {'FINISHED'}

class OBJECT_OT_MoveToGround(bpy.types.Operator):
    """Move selected objects to the ground level (lowest bounding box point)"""
    bl_idname = "object.move_to_ground"
    bl_label = "Move to Ground"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                min_z = min((obj.matrix_world @ v.co).z for v in obj.data.vertices)
                obj.location.z -= min_z
        return {'FINISHED'}

class OBJECT_OT_MoveToCenter(bpy.types.Operator):
    """Move selected objects to world center"""
    bl_idname = "object.move_to_center"
    bl_label = "Move to Center"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            obj.location = (0, 0, 0)
        return {'FINISHED'}

class OBJECT_OT_ResetTransforms(bpy.types.Operator):
    """Reset location, rotation, and scale"""
    bl_idname = "object.reset_transforms"
    bl_label = "Reset Transforms"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.selected_objects:
            obj.location = (0, 0, 0)
            obj.rotation_euler = (0, 0, 0)
            obj.scale = (1, 1, 1)
        return {'FINISHED'}

class OBJECT_OT_ApplyTransform(bpy.types.Operator):
    """Apply all transformations"""
    bl_idname = "object.apply_transform"
    bl_label = "Apply Transforms"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        return {'FINISHED'}

class OBJECT_OT_PurgeData(bpy.types.Operator):
    """Purge unused materials, meshes, and other orphaned data"""
    bl_idname = "object.purge_data"
    bl_label = "Purge Unused Data"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.outliner.orphans_purge(do_recursive=True)
        return {'FINISHED'}

class OBJECT_OT_DeleteHierarchy(bpy.types.Operator):
    """Delete selected objects and their hierarchy"""
    bl_idname = "object.delete_hierarchy"
    bl_label = "Delete Hierarchy"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects.copy()
        for obj in selected_objects:
            # Select the object and its children
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)  # Select parent
            context.view_layer.objects.active = obj
            # Select all children
            bpy.ops.object.select_grouped(type='CHILDREN_RECURSIVE')
            # Make sure parent is still selected
            obj.select_set(True)  
            # Delete the object and its children
            bpy.ops.object.delete()
        return {'FINISHED'}


class OBJECT_OT_DuplicateInstance(bpy.types.Operator):
    """Duplicate as an instance"""
    bl_idname = "object.duplicate_instance"
    bl_label = "Duplicate as Instance"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.object.duplicate(linked=True)
        return {'FINISHED'}

class OBJECT_OT_SetPivot(bpy.types.Operator):
    bl_idname = "object.set_pivot"
    bl_label = "Set Pivot Point"
    bl_options = {'REGISTER', 'UNDO'}
    
    pivot_type: bpy.props.EnumProperty(
        items=[
            ('CENTER', 'Center', 'Set pivot to center'),
            ('BOTTOM', 'Bottom', 'Set pivot to bottom'),
            ('TOP', 'Top', 'Set pivot to top'),
            ('CURSOR', 'Cursor', 'Set pivot to 3D cursor')
        ],
        name="Pivot Type",
        default='CENTER'
    )
    
    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'ERROR'}, "No active object")
            return {'CANCELLED'}
            
        if self.pivot_type == 'CENTER':
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        elif self.pivot_type == 'BOTTOM':
            # Save current cursor location
            cursor_loc = context.scene.cursor.location.copy()
            # Get object bounds
            bounds = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
            lowest_z = min(v.z for v in bounds)
            # Set cursor to bottom center
            context.scene.cursor.location = obj.location
            context.scene.cursor.location.z = lowest_z
            # Set origin to cursor
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            # Restore cursor location
            context.scene.cursor.location = cursor_loc
        elif self.pivot_type == 'TOP':
            cursor_loc = context.scene.cursor.location.copy()
            bounds = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
            highest_z = max(v.z for v in bounds)
            context.scene.cursor.location = obj.location
            context.scene.cursor.location.z = highest_z
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            context.scene.cursor.location = cursor_loc
        elif self.pivot_type == 'CURSOR':
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            
        return {'FINISHED'}

# --- UI Panels ---
class OBJECT_PT_ItemTransformPanel(bpy.types.Panel):
    bl_label = "Item Transform"
    bl_idname = "OBJECT_PT_item_transform"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "object"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.item_transform_props
        obj = context.object

        if not obj:
            layout.label(text="No active object", icon='ERROR')
            return

        # Transform Factors
        box = layout.box()
        box.label(text="Transform Factors:", icon='DRIVER_TRANSFORM')
        col = box.column(align=True)
        col.prop(props, "move_factor", text="Move")
        col.prop(props, "rotate_factor", text="Rotate")
        col.prop(props, "scale_factor", text="Scale")

        # Quick Transform
        box = layout.box()
        box.label(text="Quick Transform:", icon='OBJECT_ORIGIN')
        
        # Move Controls
        col = box.column(align=True)
        col.label(text="Move:", icon='EMPTY_DATA')
        
        grid = col.grid_flow(columns=3, align=True)
        # Forward/Backward
        op = grid.operator("object.quick_transform", text="↑")
        op.transform_type, op.direction = "MOVE", "FORWARD"
        op = grid.operator("object.quick_transform", text="↓")
        op.transform_type, op.direction = "MOVE", "BACKWARD"
        grid.separator()
        # Left/Right
        op = grid.operator("object.quick_transform", text="← ←")
        op.transform_type, op.direction = "MOVE", "LEFT"
        op = grid.operator("object.quick_transform", text="→ →")
        op.transform_type, op.direction = "MOVE", "RIGHT"
        grid.separator()
        # Up/Down
        op = grid.operator("object.quick_transform", text="⇡⇡")
        op.transform_type, op.direction = "MOVE", "UP"
        op = grid.operator("object.quick_transform", text="⇣⇣")
        op.transform_type, op.direction = "MOVE", "DOWN"

        # Rotate Controls
        col.separator()
        col.label(text="Rotate:", icon='DRIVER_ROTATIONAL_DIFFERENCE')
        row = col.row(align=True)
        for axis in ['X', 'Y', 'Z']:
            op = row.operator("object.quick_transform", text=f"{axis}")
            op.transform_type = "ROTATE"
            op.direction = axis

        # Scale Controls
        col.separator()
        col.label(text="Scale:", icon='FULLSCREEN_ENTER')
        row = col.row(align=True)
        op = row.operator("object.quick_transform", text="Scale +")
        op.transform_type, op.direction = "SCALE", "UP"
        op = row.operator("object.quick_transform", text="Scale -")
        op.transform_type, op.direction = "SCALE", "DOWN"

        # Object Info
        box = layout.box()
        box.label(text="Object Info:", icon='OBJECT_DATA')
        col = box.column(align=True)
        col.prop(obj, "dimensions")

        # Pivot Tools
        box = layout.box()
        box.label(text="Pivot Tools:", icon='OBJECT_ORIGIN')
        col = box.column(align=True)
        col.prop(props, "pivot_point", text="")
        
        row = col.row(align=True)
        for pivot_type in ['CENTER', 'BOTTOM', 'TOP', 'CURSOR']:
            op = row.operator("object.set_pivot", text=pivot_type[0])
            op.pivot_type = pivot_type

        # Transform Operations
        box = layout.box()
        box.label(text="Transform Operations:", icon='MODIFIER')
        col = box.column(align=True)
        row = col.row(align=True)
        row.operator("object.move_to_ground", text="To Ground", icon='TRIA_DOWN')
        row.operator("object.move_to_center", text="To Center", icon='OBJECT_ORIGIN')
        
        row = col.row(align=True)
        row.operator("object.reset_transforms", text="Reset", icon='RECOVER_LAST')
        row.operator("object.apply_transform", text="Apply", icon='FILE_TICK')

        # Utilities
        box = layout.box()
        box.label(text="Utilities:", icon='TOOL_SETTINGS')
        col = box.column(align=True)
        row = col.row(align=True)
        row.operator("object.purge_data", text="Purge", icon='TRASH')
        row.operator("object.delete_hierarchy", text="Delete", icon='X')
        col.operator("object.duplicate_instance", icon='DUPLICATE')

class VIEW3D_MT_PIE_item_transform(bpy.types.Menu):
    bl_label = "Item Transform Pie"
    bl_idname = "VIEW3D_MT_PIE_item_transform"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        
        # Left
        op = pie.operator("object.quick_transform", text="Move Left")
        op.transform_type, op.direction = "MOVE", "LEFT"
        
        # Right
        op = pie.operator("object.quick_transform", text="Move Right")
        op.transform_type, op.direction = "MOVE", "RIGHT"
        
        # Bottom
        op = pie.operator("object.quick_transform", text="Move Down")
        op.transform_type, op.direction = "MOVE", "DOWN"
        
        # Top
        op = pie.operator("object.quick_transform", text="Move Up")
        op.transform_type, op.direction = "MOVE", "UP"
        
        # Top-Left
        pie.operator("object.move_to_ground", text="To Ground")
        
        # Top-Right
        pie.operator("object.move_to_center", text="To Center")
        
        # Bottom-Left
        pie.operator("object.reset_transforms", text="Reset")
        
        # Bottom-Right
        pie.operator("object.apply_transform", text="Apply")

class OBJECT_OT_call_transform_pie(bpy.types.Operator):
    bl_idname = "object.call_transform_pie"
    bl_label = "Call Transform Pie Menu"
    
    def execute(self, context):
        bpy.ops.wm.call_menu_pie(name="VIEW3D_MT_PIE_item_transform")
        return {'FINISHED'}

#  keymaps 
addon_keymaps = []    

# --- Registration ---
classes = [
    ITEM_TRANSFORM_Properties,
    OBJECT_OT_QuickTransform,
    OBJECT_OT_MoveToGround,
    OBJECT_OT_MoveToCenter,
    OBJECT_OT_ResetTransforms,
    OBJECT_OT_ApplyTransform,
    OBJECT_OT_PurgeData,
    OBJECT_OT_DeleteHierarchy,
    OBJECT_OT_DuplicateInstance,
    OBJECT_OT_SetPivot,
    OBJECT_PT_ItemTransformPanel,
    VIEW3D_MT_PIE_item_transform,  
    OBJECT_OT_call_transform_pie
]

def register():
    for cls in classes:
        register_class(cls)
    bpy.types.Scene.item_transform_props = bpy.props.PointerProperty(type=ITEM_TRANSFORM_Properties)
    
    # Add keymap
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name='Object Mode', space_type='EMPTY')
        kmi = km.keymap_items.new(
            "object.call_transform_pie",
            type='T',
            value='PRESS',
            shift=True,
            alt=True
        )
        addon_keymaps.append((km, kmi))

def unregister():
    # Remove keymap
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    
    for cls in reversed(classes):
        unregister_class(cls)
    del bpy.types.Scene.item_transform_props

if __name__ == "__main__":
    register()
